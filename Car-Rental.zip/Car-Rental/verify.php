<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_captcha = trim($_POST['user_captcha']);
    $stored_captcha = $_SESSION['captcha'];

    if ($user_captcha === $stored_captcha) {
        // CAPTCHA is correct, redirect to next page
        header("Location: nextpage.php");
        exit();
    } else {
        // CAPTCHA is incorrect, redirect back with error
        header("Location: captcha.php?error=1");
        exit();
    }
} else {
    // If accessed directly
    header("Location: captcha.php");
    exit();
}
