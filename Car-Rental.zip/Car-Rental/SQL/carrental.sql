-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2025 at 01:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '21e9f89f8a6bcf66e06ef54444140ab0', '2025-02-08 06:29:12');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL,
  `BookingNumber` bigint(12) DEFAULT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `LastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `BookingNumber`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `Status`, `PostingDate`, `LastUpdationDate`) VALUES
(1, 443108139, 'amikt12@gmail.com', 2, '2024-06-08', '2024-06-10', 'I want booking', 1, '2024-06-05 05:32:39', '2024-06-05 05:34:08'),
(2, 880418418, 'mathan12@gmail.com', 8, '2024-12-14', '2024-12-17', 'hii', 2, '2024-12-14 04:14:26', '2024-12-14 04:16:35'),
(3, 390511321, 'sakthiwarlord2004@gmail.com', 1, '2025-02-14', '2025-02-21', 'hih', 1, '2025-02-13 08:03:43', '2025-02-19 13:22:32'),
(4, 267630918, 'www.mathan54321@gmail.com', 11, '2025-02-21', '2025-02-24', 'urgent sir.', 1, '2025-02-20 03:45:51', '2025-02-20 03:46:39'),
(5, 816468857, 'www.mathan54321@gmail.com', 2, '2025-02-21', '2025-02-28', 'hii', 1, '2025-02-21 09:09:37', '2025-02-21 09:10:45'),
(6, 924265497, 'www.mathan54321@gmail.com', 3, '2025-02-22', '2025-02-24', 'hii sir', 1, '2025-02-22 09:45:12', '2025-02-22 09:46:32'),
(7, 343894229, 'sakthiwarlord2004@gmail.com', 10, '2025-02-24', '2025-03-01', 'i am sakthi', 2, '2025-02-24 08:07:26', '2025-02-25 04:24:33'),
(8, 964177975, 'kesavanram07@gmail.com', 8, '2025-04-02', '2025-04-05', 'give me rent cars.', 1, '2025-04-02 05:11:57', '2025-04-02 05:12:47');

-- --------------------------------------------------------

--
-- Table structure for table `tblbrands`
--

CREATE TABLE `tblbrands` (
  `id` int(11) NOT NULL,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Maruti', '2025-01-02 10:24:34', '2025-01-02 10:24:34'),
(2, 'BMW', '2025-02-01 09:24:34', '2025-02-01 09:24:34'),
(3, 'Audi', '2025-02-01 09:24:34', '2025-02-01 09:24:34'),
(4, 'Nissan', '2025-02-01 09:24:34', '2025-02-01 09:24:34'),
(5, 'Toyota', '2025-02-01 09:24:34', '2025-02-01 09:24:34'),
(6, 'Volkswagon', '2025-02-01 09:24:34', '2025-02-01 09:24:34'),
(7, 'Tata', '2025-01-30 04:01:00', '2025-01-30 04:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'keela raja veethi,pudukkottai', 'shreeram56881@gmail.com', '6381761984');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'gugan', 'gugan12@gmail.com', '7977779798', 'I want to know you branch in Chennai?', '2025-02-03 19:34:51', 1),
(2, 'mathan raja', 'www.mathan54321@gmail.com', '1234567890', 'hiiii', '2025-02-08 14:42:54', 1),
(3, 'Kesavan ramanathan', 'kesavanram07@gmail.com', '8825407478', 'hi.gearbox broken.', '2025-04-02 05:18:21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1, 'Terms and Conditions', 'terms', '<head>\r\n    <style>\r\n        body {\r\n            font-family: \"Poppins\", Arial, sans-serif;\r\n            background-color: #f9f9f9;\r\n            color: #333;\r\n            margin: 0;\r\n            padding: 20px;\r\n        }\r\n        .terms-container {\r\n            max-width: 900px;\r\n            margin: auto;\r\n            background: #fff;\r\n            padding: 30px;\r\n            border-radius: 10px;\r\n            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\r\n        }\r\n        .terms-container h2 {\r\n            font-size: 28px;\r\n            font-weight: 600;\r\n            color: #990000;\r\n            text-align: center;\r\n            margin-bottom: 20px;\r\n        }\r\n        .terms-container h3 {\r\n            font-size: 22px;\r\n            font-weight: 600;\r\n            color: #990000;\r\n            margin-top: 25px;\r\n        }\r\n        .terms-container p, .terms-container ul {\r\n            font-size: 16px;\r\n            line-height: 1.6;\r\n            text-align: justify;\r\n            margin-bottom: 15px;\r\n        }\r\n        .terms-container ul {\r\n            padding-left: 20px;\r\n        }\r\n        .terms-container ul li {\r\n            margin-bottom: 10px;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n\r\n<div class=\"terms-container\">\r\n    <h2>Terms of Service</h2>\r\n\r\n    <h3>(1) ACCEPTANCE OF TERMS</h3>\r\n    <p>Welcome to Our Car Rental Service. Our Car Rental Service provides the services outlined below to you, subject to the following Terms of Service (\"TOS\"). By accessing or using our services, you agree to these terms, which may be updated by us periodically without prior notice. You can review the most current version of the TOS on our website at any time.</p>\r\n    <p>When using particular features or services, you may also be subject to any additional guidelines or rules applicable to those features, which will be clearly posted. All such guidelines or rules are incorporated by reference into these TOS. In the event of a conflict between the TOS and specific service guidelines, these TOS will prevail unless explicitly stated otherwise.</p>\r\n    <p>We may introduce new services or features that are governed by separate terms. These TOS will not apply to such new services unless specifically stated. Please review the applicable terms when accessing any new services.</p>\r\n\r\n    <h3>(2) SERVICE USAGE</h3>\r\n    <p>By using our car rental service, you agree to:</p>\r\n    <ul>\r\n        <li>Provide accurate and complete information during the booking process.</li>\r\n        <li>Use our vehicles responsibly and adhere to all traffic and safety regulations.</li>\r\n        <li>Return the vehicle in the same condition as it was rented, subject to normal wear and tear.</li>\r\n    </ul>\r\n    <p>Failure to comply with these obligations may result in additional charges or penalties.</p>\r\n\r\n    <h3>(3) PAYMENT AND CANCELLATION</h3>\r\n    <ul>\r\n        <li>All rentals must be prepaid or secured with a valid credit card.</li>\r\n        <li>Cancellation policies vary based on the booking class and will be clearly stated at the time of booking.</li>\r\n        <li>Refunds, if applicable, will be processed according to our cancellation policy.</li>\r\n    </ul>\r\n\r\n    <h3>(4) LIMITATION OF LIABILITY</h3>\r\n    <p>Car Rental Service is not responsible for:</p>\r\n    <ul>\r\n        <li>Delays caused by unforeseen circumstances, including but not limited to weather, traffic, or mechanical issues.</li>\r\n        <li>Personal items left in the vehicle during or after the rental period.</li>\r\n    </ul>\r\n    <p>Our liability is limited to the rental amount paid for the specific booking.</p>\r\n\r\n    <h3>(5) MODIFICATIONS TO THE SERVICE</h3>\r\n    <p>We reserve the right to modify, suspend, or discontinue any part of our service at any time without prior notice. We will not be liable to you or any third party for such modifications, suspensions, or discontinuations.</p>\r\n\r\n    <h3>(6) GOVERNING LAW</h3>\r\n    <p>These Terms of Service are governed by the laws of India. Any disputes arising from the use of our services will be subject to the jurisdiction of the courts in Pudukkottai.</p>\r\n</div>\r\n\r\n</body>\r\n</html>\r\n'),
(2, 'Privacy Policy', 'privacy', '<head>\r\n    <style>\r\n        .about-container {\r\n            max-width: 800px;\r\n            margin: auto;\r\n            font-family: \"Poppins\", Arial, sans-serif;\r\n            font-size: 16px;\r\n            color: #333;\r\n            line-height: 1.6;\r\n            text-align: justify;\r\n        }\r\n        .about-container h2 {\r\n            font-size: 28px;\r\n            font-weight: 600;\r\n            color: #990000;\r\n            text-align: center;\r\n            margin-bottom: 20px;\r\n        }\r\n        .about-container p {\r\n            margin-bottom: 15px;\r\n        }\r\n        .email-link {\r\n            color: #990000;\r\n            font-weight: bold;\r\n            text-decoration: none;\r\n        }\r\n        .email-link:hover {\r\n            text-decoration: underline;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n\r\n<div class=\"about-container\">\r\n    <!-- <h2>Privacy Policy</h2> -->\r\n    <p>At <strong>CAR RENTAL PORTAL</strong>, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.</p>\r\n\r\n    <p>We may collect personal information such as your name, contact details, payment information, and rental history to provide our services efficiently. Your data is used solely for processing bookings, improving our services, and ensuring a seamless rental experience.</p>\r\n\r\n    <p>We implement security measures to protect your information from unauthorized access or misuse. However, no data transmission over the internet is 100% secure, and we encourage users to take necessary precautions.</p>\r\n\r\n    <p>By using our website, you consent to our data practices outlined in this Privacy Policy. If you have any concerns or questions, please contact us at  \r\n        <a href=\"mailto:shreeram56881@gmail.com\" class=\"email-link\">shreeram56881@gmail.com</a>.\r\n    </p>\r\n\r\n    <p>We reserve the right to update this policy as needed. Please review this page periodically for any changes.</p>\r\n</div>\r\n\r\n</body>'),
(3, 'About Us ', 'aboutus', '<head>\r\n    <style>\r\n        .about-container {\r\n            max-width: 800px;\r\n            margin: auto;\r\n            font-family: \"Poppins\", Arial, sans-serif;\r\n            font-size: 16px;\r\n            color: #333;\r\n            line-height: 1.8;\r\n            text-align: justify;\r\n            background: #f9f9f9;\r\n            padding: 20px;\r\n            border-radius: 10px;\r\n            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);\r\n        }\r\n        .about-container h2 {\r\n            font-size: 30px;\r\n            font-weight: 700;\r\n            color: #990000;\r\n            text-align: center;\r\n            margin-bottom: 20px;\r\n            text-transform: uppercase;\r\n        }\r\n        .about-container p {\r\n            margin-bottom: 15px;\r\n        }\r\n        .about-container strong {\r\n            color: #990000;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n\r\n<div class=\"about-container\">\r\n    <!-- <h2>About Us</h2> -->\r\n    \r\n    <p>Welcome to <strong>CAR RENTAL PORTAL</strong>, your trusted destination for hassle-free car rentals. We provide a seamless online booking experience, offering a wide range of vehicles to suit your needs.</p>\r\n\r\n    <p>Our mission is to deliver <strong>convenience and affordability</strong>, making travel easier for everyone. Whether you need a car for a business trip, vacation, or daily commute, we ensure you get the best options at competitive rates.</p>\r\n\r\n    <p>With a <strong>customer-centric approach</strong>, we prioritize <strong>safety, quality, and reliability</strong>. Our fleet includes well-maintained vehicles from top brands, ensuring comfort and efficiency on the road.</p>\r\n\r\n    <p>Experience the ease of renting a car with just a few clicks. Choose <strong>CAR RENTAL PORTAL</strong> for a smooth and enjoyable ride.</p>\r\n</div>\r\n\r\n</body>\r\n</html>\r\n'),
(11, 'FAQs', 'faqs', '<head>\r\n    <style>\r\n        body {\r\n            font-family: Arial, sans-serif;\r\n            background-color: #f9f9f9;\r\n            margin: 0;\r\n            padding: 20px;\r\n        }\r\n        .faq-container {\r\n            max-width: 800px;\r\n            margin: auto;\r\n            background: #fff;\r\n            padding: 20px;\r\n            border-radius: 10px;\r\n            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\r\n        }\r\n        .faq-container h2 {\r\n            text-align: center;\r\n            color: #990000;\r\n        }\r\n        .faq-item {\r\n            margin-bottom: 20px;\r\n            border-bottom: 1px solid #ddd;\r\n            padding-bottom: 10px;\r\n        }\r\n        .question {\r\n            color: #990000;\r\n            font-weight: bold;\r\n            font-size: 16px;\r\n            cursor: pointer;\r\n            display: block;\r\n            margin-bottom: 5px;\r\n        }\r\n        .answer {\r\n            font-size: 14px;\r\n            display: none;\r\n        }\r\n        .contact-info {\r\n            text-align: center;\r\n            margin-top: 20px;\r\n        }\r\n        .contact-info a {\r\n            color: #990000;\r\n            text-decoration: none;\r\n            font-weight: bold;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n    <div class=\"faq-container\">\r\n        <h2>Frequently Asked Questions</h2>\r\n        \r\n        <div class=\"faq-item\">\r\n            <span class=\"question\">(1) How can I book a car with Car Rental Service?</span>\r\n            <p class=\"answer\">Booking a car is simple! Visit our website, select a vehicle, choose rental dates, and complete the booking process online. You can also contact customer service for assistance.</p>\r\n        </div>\r\n        \r\n        <div class=\"faq-item\">\r\n            <span class=\"question\">(2) What documents do I need to rent a car?</span>\r\n            <p class=\"answer\">You will need a valid driver’s license, a government-issued photo ID (passport, national ID, etc.), and a valid credit or debit card for payment and security deposit.</p>\r\n        </div>\r\n        \r\n        <div class=\"faq-item\">\r\n            <span class=\"question\">(3) Are there any age restrictions for renting a car?</span>\r\n            <p class=\"answer\">Yes, the minimum age to rent a car is typically 21 years. Drivers under 25 may be subject to a young driver surcharge.</p>\r\n        </div>\r\n        \r\n        <div class=\"faq-item\">\r\n            <span class=\"question\">(4) What happens if I return the car late?</span>\r\n            <p class=\"answer\">Late returns may incur additional charges. Please inform us in advance if you anticipate a delay to avoid penalties.</p>\r\n        </div>\r\n        \r\n        <div class=\"contact-info\">\r\n            <p>Contact Us:</p>\r\n            <p>Phone: <a href=\"tel:+916381761984\">+91 6381761984</a></p>\r\n            <p>Email: <a href=\"mailto:shreeram56881@gmail.com\">shreeram56881@gmail.com</a></p>\r\n        </div>\r\n    </div>\r\n\r\n    <script>\r\n        document.querySelectorAll(\'.question\').forEach(item => {\r\n            item.addEventListener(\'click\', () => {\r\n                let answer = item.nextElementSibling;\r\n                answer.style.display = answer.style.display === \'block\' ? \'none\' : \'block\';\r\n            });\r\n        });\r\n    </script>\r\n</body>\r\n</html>');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblsubscribers`
--

INSERT INTO `tblsubscribers` (`id`, `SubscriberEmail`, `PostingDate`) VALUES
(1, 'kesavan@gmail.com', '2025-02-02 05:26:21'),
(2, 'gugan12@gmail.com', '2025-02-02 05:35:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbltestimonial`
--

CREATE TABLE `tbltestimonial` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `Testimonial` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL,
  `Rating` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbltestimonial`
--

INSERT INTO `tbltestimonial` (`id`, `UserEmail`, `Testimonial`, `PostingDate`, `status`, `Rating`) VALUES
(1, 'sakthiwarlord2004@gmail.com', 'This is a great service! Highly recommended.', '2025-01-30 03:55:06', 1, 5),
(2, 'akash123@gmail.com', 'The service was decent but could be improved.', '2025-01-30 03:56:45', 1, 3),
(3, 'mathan54321@gmail.com', 'The experience was below average and needs improvement.', '2025-01-30 03:58:30', 1, 2),
(4, 'sakthiwarlord2004@gmail.com', 'Good service, but there is room for improvement.', '2025-01-30 03:58:30', 1, 4),
(5, 'kesavanram07@gmail.com', 'ITS A NICE RENTAL SERVICE.THANK YOU.', '2025-04-02 05:14:27', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `LicensePath` varchar(255) DEFAULT NULL,
  `ProfilePhotoPath` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`, `LicensePath`, `ProfilePhotoPath`) VALUES
(1, 'sakthi', 'sakthiwarlord2004@gmail.com', 'cee1f86a3b75f70e97b71ad01e821a80', '9043129386', '23/11/2004', 'puthuvalavu, keelakottai ', 'kallal', 'India', '2024-05-01 14:00:49', '2025-02-24 08:05:19', 'uploads/licenses/', 'uploads/photos/sakthi.jpg'),
(2, 'Akash', 'akash123@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '1425365214', '06/10/2003', 'sarugani', 'devakottai', 'india', '2024-06-05 05:31:05', NULL, NULL, NULL),
(3, 'sriram', 'jackrosee354@gmail.com', '144cd45ba45afb2989c58b06dd2473b5', '8667516626', NULL, NULL, NULL, NULL, '2025-02-02 08:34:15', '2025-02-20 03:37:50', NULL, NULL),
(9, 'mathan', 'www.mathan54321@gmail.com', '42a5d584b846bcd1a8d6f38470ee93d9', '6381761984', '10/10/2004', '5/29 jayanthi colony rangiem', 'pudugai', 'india', '2025-02-22 09:38:26', '2025-02-22 10:22:32', 'uploads/licenses/', 'uploads/photos/IMG_20240707_150858_694.jpg'),
(10, 'Kesavan ramanathan', 'kesavanram07@gmail.com', 'bce7862559c1c980b376cbb1a6d9fa0f', '8825407478', NULL, NULL, NULL, NULL, '2025-04-02 05:10:06', NULL, 'uploads/licenses/akash.jpg', 'uploads/photos/IMG_20230428_120721.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicles`
--

CREATE TABLE `tblvehicles` (
  `id` int(11) NOT NULL,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext DEFAULT NULL,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage1` varchar(120) DEFAULT NULL,
  `Vimage2` varchar(120) DEFAULT NULL,
  `Vimage3` varchar(120) DEFAULT NULL,
  `Vimage4` varchar(120) DEFAULT NULL,
  `Vimage5` varchar(120) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblvehicles`
--

INSERT INTO `tblvehicles` (`id`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage1`, `Vimage2`, `Vimage3`, `Vimage4`, `Vimage5`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
(1, 'Maruti Suzuki Wagon R', 1, 'Maruti Wagon R Latest Updates\r\n\r\nMaruti Suzuki has launched the BS6 Wagon R S-CNG in India. The LXI CNG and LXI (O) CNG variants now cost Rs 5.25 lakh and Rs 5.32 lakh respectively, up by Rs 19,000. Maruti claims a fuel economy of 32.52km per kg. The CNG Wagon R’s continuation in the BS6 era is part of the carmaker’s ‘Mission Green Million’ initiative announced at Auto Expo 2020.\r\n\r\nPreviously, the carmaker had updated the 1.0-litre powertrain to meet BS6 emission norms. It develops 68PS of power and 90Nm of torque, same as the BS4 unit. However, the updated motor now returns 21.79 kmpl, which is a little less than the BS4 unit’s 22.5kmpl claimed figure. Barring the CNG variants, the prices of the Wagon R 1.0-litre have been hiked by Rs 8,000.', 1500, 'Petrol', 2019, 5, 'rear-3-4-left-589823254_930x620.jpg', 'tail-lamp-1666712219_930x620.jpg', 'rear-3-4-right-520328200_930x620.jpg', 'steering-close-up-1288209207_930x620.jpg', 'boot-with-standard-luggage-202327489_930x620.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2025-02-08 10:07:36'),
(2, 'BMW 5 Series', 2, 'BMW 5 Series price starts at ? 55.4 Lakh and goes upto ? 68.39 Lakh. The price of Petrol version for 5 Series ranges between ? 55.4 Lakh - ? 60.89 Lakh and the price of Diesel version for 5 Series ranges between ? 60.89 Lakh - ? 68.39 Lakh.', 7500, 'Petrol', 2018, 5, 'BMW-5-Series-Exterior-102005.jpg', 'BMW-5-Series-New-Exterior-89729.jpg', 'BMW-5-Series-Exterior-102006.jpg', 'BMW-5-Series-Interior-102021.jpg', 'BMW-5-Series-Interior-102022.jpg', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 1, 1, 1, '2024-05-10 07:04:35', '2025-02-08 10:06:29'),
(3, 'Audi Q8', 3, 'As per ARAI, the mileage of Q8 is 0 kmpl. Real mileage of the vehicle varies depending upon the driving habits. City and highway mileage figures also vary depending upon the road conditions.', 3000, 'Petrol', 2017, 5, 'audi-q8-front-view4.jpg', '1920x1080_MTC_XL_framed_Audi-Odessa-Armaturen_Spiegelung_CC_v05.jpg', 'audi1.jpg', '1audiq8.jpg', 'audi-q8-front-view4.jpeg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(4, 'Nissan Kicks', 4, 'Latest Update: Nissan has launched the Kicks 2020 with a new turbocharged petrol engine. You can read more about it here.\r\n\r\nNissan Kicks Price and Variants: The Kicks is available in four variants: XL, XV, XV Premium, and XV Premium(O).', 4500, 'Petrol', 2020, 5, 'front-left-side-47.jpg', 'kicksmodelimage.jpg', 'download.jpg', 'kicksmodelimage.jpg', '', 1, NULL, NULL, 1, NULL, NULL, 1, 1, NULL, NULL, NULL, 1, '2024-05-10 07:04:35', '2025-02-08 10:06:50'),
(5, 'Nissan GT-R', 4, ' The GT-R packs a 3.8-litre V6 twin-turbocharged petrol, which puts out 570PS of max power at 6800rpm and 637Nm of peak torque. The engine is mated to a 6-speed dual-clutch transmission in an all-wheel-drive setup. The 2+2 seater GT-R sprints from 0-100kmph in less than 3', 2000, 'Petrol', 2019, 5, 'Nissan-GTR-Right-Front-Three-Quarter-84895.jpg', 'Best-Nissan-Cars-in-India-New-and-Used-1.jpg', '2bb3bc938e734f462e45ed83be05165d.jpg', '2020-nissan-gtr-rakuda-tan-semi-aniline-leather-interior.jpg', 'images.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(6, 'Nissan Sunny 2020', 4, 'Value for money product and it was so good It is more spacious than other sedans It looks like a luxurious car.', 400, 'CNG', 2018, 5, 'Nissan-Sunny-Right-Front-Three-Quarter-48975_ol.jpg', 'images (1).jpg', 'Nissan-Sunny-Interior-114977.jpg', 'nissan-sunny-8a29f53-500x375.jpg', 'new-nissan-sunny-photo.jpg', 1, 1, NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(7, 'Toyota Fortuner', 5, 'Toyota Fortuner Features: It is a premium seven-seater SUV loaded with features such as LED projector headlamps with LED DRLs, LED fog lamp, and power-adjustable and foldable ORVMs. Inside, the Fortuner offers features such as power-adjustable driver seat, automatic climate control, push-button stop/start, and cruise control.\r\n\r\nToyota Fortuner Safety Features: The Toyota Fortuner gets seven airbags, hill assist control, vehicle stability control with brake assist, and ABS with EBD.', 3000, 'Petrol', 2020, 5, '2015_Toyota_Fortuner_(New_Zealand).jpg', 'toyota-fortuner-legender-rear-quarters-6e57.jpg', 'zw-toyota-fortuner-2020-2.jpg', 'download (1).jpg', '', NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1, 1, 1, '2024-05-10 07:04:35', '2024-06-05 05:30:33'),
(8, 'Maruti Suzuki Vitara Brezza', 1, 'The new Vitara Brezza is a well-rounded package that is feature-loaded and offers good drivability. And it is backed by Maruti’s vast service network, which ensures a peace of mind to customers. The petrol motor could have been more refined and offered more pep.', 1500, 'Petrol', 2018, 5, 'marutisuzuki-vitara-brezza-right-front-three-quarter3.jpg', 'marutisuzuki-vitara-brezza-rear-view37.jpg', 'marutisuzuki-vitara-brezza-dashboard10.jpg', 'marutisuzuki-vitara-brezza-boot-space59.jpg', 'marutisuzuki-vitara-brezza-boot-space28.jpg', NULL, 1, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, 1, NULL, '2024-05-10 07:04:35', '2025-02-08 10:07:08'),
(9, 'Toyota Innova Crysta', 5, 'A premium MPV with a powerful engine, spacious interior, and modern features.', 3500, 'Diesel', 2023, 7, 'innova1.png', 'innova2.jpg', 'innova3.jpg', 'innova4.jpg', 'innova1.png', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2025-01-31 05:46:41', '2025-01-31 05:51:38'),
(10, 'Tata Punch', 7, 'A compact SUV with bold design, high ground clearance, and advanced safety features.', 2500, 'Petrol', 2023, 5, 'punch1.jpg', 'punch2.jpg', 'punch3.jpg', 'punch4.jpg', 'punch5.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2025-01-31 05:57:22', '2025-01-31 05:58:24'),
(11, 'Maruti Swift', 1, 'A stylish and fuel-efficient hatchback with great performance and safety features.', 2000, 'Diesel', 2023, 5, 'swift1.jpg', 'swift2.jpg', 'swift3.jpg', 'swift4.jpg', 'swift5.jpg', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, '2025-01-31 06:01:19', '2025-01-31 06:03:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbrands`
--
ALTER TABLE `tblbrands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmailId` (`EmailId`);

--
-- Indexes for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblbrands`
--
ALTER TABLE `tblbrands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
