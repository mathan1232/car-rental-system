<?php 
session_start();
include('includes/config.php');
error_reporting(0); 

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car Rental Portal | Car Listing</title>
    <!--Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <!--Custom Style -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <!--OWL Carousel slider-->
    <link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
    <!--slick-slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!--bootstrap-slider -->
    <link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <!--FontAwesome Font Style -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
</head>
<body>

<!--Header--> 
<?php include('includes/header.php'); ?>
<!-- /Header --> 

<!--Page Header-->
<section class="page-header listing_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1>Car Listing</h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="index.php" style="color:white">Home</a></li>
        <li>Car Listing</li>
      </ul>
    </div>
  </div>
  <div class="dark-overlay"></div>
</section>
<!-- /Page Header--> 

<!--Listing-->
<section class="listing-page">
  <div class="container">
    <div class="row">
      <div class="col-md-9 col-md-push-3">
        <div class="result-sorting-wrapper">
          <div class="sorting-count">
<?php 
// Retrieve parameters from URL
$brand = isset($_GET['brand']) ? trim($_GET['brand']) : '';
$fueltype = isset($_GET['fueltype']) ? trim($_GET['fueltype']) : '';

// Append % for LIKE query
$brand = "%" . $brand . "%";
$fueltype = "%" . $fueltype . "%";

// Debugging output
//echo "Debug: Brand = '$brand', Fuel Type = '$fueltype'<br>";

// Query for Listing count
$sql = "SELECT * FROM tblvehicles WHERE VehiclesTitle LIKE :brand AND FuelType LIKE :fueltype";
//$sql = "SELECT id FROM tblvehicles WHERE VehiclesBrand LIKE ':brand%' AND FuelType LIKE ':fueltype%'";
$query = $dbh->prepare($sql);
$query->bindParam(':brand', $brand, PDO::PARAM_STR);
$query->bindParam(':fueltype', $fueltype, PDO::PARAM_STR);
$query->execute();
$cnt = $query->rowCount();

//echo "Debug: Listing count query executed successfully. Count: $cnt<br>";
?>
<p><span><?php echo htmlentities($cnt); ?> Listings</span></p>
</div>
</div>

<?php 
// Fetch and display car listings
$sql = "SELECT tblvehicles.*, tblbrands.BrandName, tblbrands.id AS bid 
        FROM tblvehicles 
        JOIN tblbrands ON tblbrands.id = tblvehicles.VehiclesBrand 
        WHERE tblvehicles.VehiclesTitle LIKE :brand AND tblvehicles.FuelType LIKE :fueltype";
$query = $dbh->prepare($sql);
$query->bindParam(':brand', $brand, PDO::PARAM_STR);
$query->bindParam(':fueltype', $fueltype, PDO::PARAM_STR);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);

if ($query->rowCount() > 0) {
    foreach ($results as $result) {  
?>
        <div class="product-listing-m gray-bg">
          <div class="product-listing-img">
            <img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1); ?>" class="img-responsive" alt="Image" />
          </div>
          <div class="product-listing-content">
            <h5>
              <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id); ?>">
                <?php echo htmlentities($result->BrandName); ?>, <?php echo htmlentities($result->VehiclesTitle); ?>
              </a>
            </h5>
            <p class="list-price">₹<?php echo htmlentities($result->PricePerDay); ?> Per Day</p>
            <ul>
              <li><i class="fa fa-user" aria-hidden="true"></i><?php echo htmlentities($result->SeatingCapacity); ?> seats</li>
              <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo htmlentities($result->ModelYear); ?> model</li>
              <li><i class="fa fa-car" aria-hidden="true"></i><?php echo htmlentities($result->FuelType); ?></li>
            </ul>
            <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id); ?>" class="btn">
              View Details <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
            </a>
          </div>
        </div>
<?php 
    }
} else {
    echo "Debug: No listings found for the given brand and fuel type.";
}
?>
         </div>
      
      <!--Side-Bar-->
      <aside class="col-md-3 col-md-pull-9">
        <!-- Sidebar content -->
      </aside>
      <!--/Side-Bar--> 
    </div>
  </div>
</section>
<!-- /Listing--> 

<!--Footer -->
<?php include('includes/footer.php'); ?>
<!-- /Footer--> 

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>
</body>
</html>
