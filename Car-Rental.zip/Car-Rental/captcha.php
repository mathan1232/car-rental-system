<?php
session_start();

// Initialize variables
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_captcha'])) {
    $user_captcha = trim($_POST['user_captcha']);
    $stored_captcha = $_SESSION['captcha'];

    if ($user_captcha === $stored_captcha) {
        $success = "✅ CAPTCHA Verified! Starting Your Ride...";
        unset($_SESSION['captcha']);  // Clear CAPTCHA after success
        header("refresh:2;url=update-password.php"); // Redirect after 2 seconds
    } else {
        $error = "❌ Wrong Code! Please Re-enter.";
    }
}

// Generate a new CAPTCHA only if it doesn't exist or after a failed attempt
if (!isset($_SESSION['captcha']) || $error) {
    $captcha_code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"), 0, 6);
    $_SESSION['captcha'] = $captcha_code;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Car Rental | CAPTCHA Verification</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #fff;
        }

        /* Card Container */
        .captcha-container {
            background-color: #1e272e;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
            text-align: center;
            width: 400px;
            border: 2px solid #ff4757;
        }

        /* Header */
        .header {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .header i {
            color: #ff4757;
            margin-right: 10px;
        }

        /* CAPTCHA Code */
        .captcha-code {
            font-size: 32px;
            letter-spacing: 8px;
            background: linear-gradient(to right, #ff4757, #ff6b81);
            color: #fff;
            padding: 12px;
            border-radius: 8px;
            display: inline-block;
            margin-bottom: 15px;
            font-weight: bold;
            user-select: none;
        }

        /* Input Field */
        input[type="text"] {
            width: 80%;
            padding: 12px;
            border: 2px solid #576574;
            border-radius: 6px;
            font-size: 16px;
            background-color: #2f3542;
            color: #fff;
            margin-bottom: 15px;
        }

        input[type="text"]:focus {
            border-color: #ff4757;
            outline: none;
        }

        /* Button */
        button {
            background-color: #ff4757;
            color: #fff;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #e84118;
        }

        /* Messages */
        .error {
            color: #e84118;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .success {
            color: #2ed573;
            font-weight: bold;
            margin-bottom: 10px;
        }

        /* Footer */
        .footer {
            margin-top: 20px;
            font-size: 12px;
            color: #ced6e0;
        }
    </style>
</head>
<body>
    <div class="captcha-container">
        <div class="header">
            <i>🚗</i> Car Rental Verification
        </div>

        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <?php if ($success): ?>
            <p class="success"><?php echo $success; ?></p>
        <?php else: ?>
            <form method="post" action="">
                <div class="captcha-code"><?php echo $_SESSION['captcha']; ?></div><br>
                <input type="text" name="user_captcha" placeholder="Enter CAPTCHA Code" required><br>
                <button type="submit" name="verify">🚀 Verify & Start</button>
            </form>
        <?php endif; ?>

        <div class="footer">© 2025 Car Rental System</div>
    </div>
</body>
</html>
