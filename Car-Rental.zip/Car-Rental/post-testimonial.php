<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Check if the user is logged in
if(strlen($_SESSION['login']) == 0) { 
    header('location:index.php');
} else {
    if(isset($_POST['submit'])) {
        $testimonial = $_POST['testimonial'];
        $rating = $_POST['rating'];
        $email = $_SESSION['login'];

        // Insert testimonial and rating into the database
        $sql = "INSERT INTO tbltestimonial (UserEmail, Testimonial, Rating) VALUES (:email, :testimonial, :rating)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':testimonial', $testimonial, PDO::PARAM_STR);
        $query->bindParam(':rating', $rating, PDO::PARAM_INT);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->execute();
        
        $lastInsertId = $dbh->lastInsertId();
        if($lastInsertId) {
            $msg = "Testimonial submitted successfully";
        } else {
            $error = "Something went wrong. Please try again";
        }
    }
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car Rental Portal | Post Testimonial</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css">
    <style>
        .errorWrap {
            padding: 10px;
            margin: 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .succWrap {
            padding: 10px;
            margin: 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .testimonial-container {
            display: flex;
            gap: 20px;
        }
        .testimonial-boxes {
            width: 30%; /* Left side for testimonials */
            background: #f7f7f7;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .testimonial-boxes h5 {
            font-size: 18px;
            margin-bottom: 10px;
            text-align: center;
        }
        .post-testimonial {
            width: 70%; /* Right side for the form */
        }
        .nav-buttons {
            margin: 20px 0;
            padding: 10px;
            background: #f7f7f7;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-buttons a {
            display: block;
            padding: 10px;
            margin: 5px 0;
            text-decoration: none;
            color: #007bff;
            background: #f1f1f1;
            border-radius: 4px;
            text-align: center;
            font-size: 16px;
        }
        .nav-buttons a:hover {
            background: #007bff;
            color: white;
        }
    </style>
</head>
<body>

<!-- Include header -->
<?php include('includes/header.php'); ?>

<!-- Page Header -->
<section class="page-header profile_page">
    <div class="container">
        <div class="page-header_wrap">
            <div class="page-heading">
                <h1>Post Testimonial</h1>
            </div>
            <ul class="coustom-breadcrumb">
                <li><a href="#">Home</a></li>
                <li>Post Testimonial</li>
            </ul>
        </div>
    </div>
    <div class="dark-overlay"></div>
</section>

<!-- User Profile Section -->
<section class="user_profile inner_pages">
    <div class="container">
        <div class="testimonial-container">
            <!-- Left Side: Testimonials -->
            <div class="testimonial-boxes">
                <h5>Recent Testimonials</h5>
                <?php
                $sql = "SELECT UserEmail, Testimonial, Rating, PostingDate FROM tbltestimonial WHERE status=1 ORDER BY PostingDate DESC LIMIT 5";
                $query = $dbh->prepare($sql);
                $query->execute();
                $testimonials = $query->fetchAll(PDO::FETCH_OBJ);
                if ($query->rowCount() > 0) {
                    foreach ($testimonials as $testimonial) {
                        echo "<div class='testimonial-box'>";
                        echo "<p><strong>" . htmlentities($testimonial->UserEmail) . ":</strong></p>";
                        echo "<p>" . htmlentities($testimonial->Testimonial) . "</p>";
                        echo "<p>Rating: " . htmlentities($testimonial->Rating) . " ⭐</p>";
                        echo "<p><small>Posted on: " . htmlentities($testimonial->PostingDate) . "</small></p>";
                        echo "<hr>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No testimonials available.</p>";
                }
                ?>
            </div>

            <!-- Right Side: Post Testimonial Form -->
            <div class="post-testimonial">
                <div class="profile_wrap">
                    <h5 class="uppercase underline">Post a Testimonial</h5>
                    <?php if($error){?>
                        <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?></div>
                    <?php } else if($msg){?>
                        <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?></div>
                    <?php } ?>
                    <form method="post">
                        <div class="form-group">
                            <label class="control-label">Testimonial</label>
                            <textarea class="form-control white_bg" name="testimonial" rows="4" required></textarea>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Star Rating (1 to 5)</label>
                            <select class="form-control white_bg" name="rating" required>
                                <option value="">Select Rating</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn">Save <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span></button>
                        </div>
                    </form>

                    <!-- Navigation Buttons Section (Placed Below the Save Button) -->
                    <div class="nav-buttons">
                        <a href="profile.php">Profile Settings</a>
                        <a href="update-password.php">Update Password</a>
                        <a href="my-booking.php">My Booking</a>
                        <a href="post-testimonial.php">Post a Testimonial</a>
                        <a href="my-testimonials.php">My Testimonials</a>
                        <a href="sign-out.php">Sign Out</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Include Footer -->
<?php include('includes/footer.php'); ?>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/interface.js"></script>
</body>
</html>

<?php } ?>
