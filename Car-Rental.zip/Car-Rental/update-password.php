<?php
session_start();
error_reporting(0);
include('includes/config.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php'; // Load PHPMailer

// Redirect if not logged in
if (strlen($_SESSION['login']) == 0) { 
    header('location:index.php');
} else {
    $email = $_SESSION['login'];

    // Function to send OTP
    function sendOTP($email) {
        $otp = rand(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['otp_sent'] = true;

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'jackrosee354@gmail.com';
            $mail->Password = 'masvrjdgettibslo';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('jackrosee354@gmail.com', 'Car Rental Portal');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'OTP for Password Update';
            $mail->Body = "Your OTP for password reset is: <b>$otp</b>";

            $mail->send();
            return "OTP sent to your email.";
        } catch (Exception $e) {
            return "OTP sending failed. Mailer Error: " . $mail->ErrorInfo;
        }
    }

    // Send OTP on first request
    if (isset($_POST['sendotp'])) {
        $msg = sendOTP($email);
    }

    // Resend OTP
    if (isset($_POST['resendotp'])) {
        $msg = sendOTP($email);
    }

    // Verify OTP
    if (isset($_POST['verifyotp'])) {
        if ($_POST['otp'] == $_SESSION['otp']) {
            $_SESSION['otp_verified'] = true;
            $msg = "OTP verified successfully. Enter new password.";
        } else {
            $error = "Invalid OTP.";
        }
    }

   // Update password
if (isset($_POST['updatepass'])) {
    if ($_SESSION['otp_verified']) {
        $newpassword = md5($_POST['newpassword']);
        $chngpwd1 = $dbh->prepare("UPDATE tblusers SET Password=:newpassword WHERE EmailId=:email");
        $chngpwd1->bindParam(':email', $email, PDO::PARAM_STR);
        $chngpwd1->bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
        $chngpwd1->execute();
        
        // Clear session after success
        unset($_SESSION['otp'], $_SESSION['otp_sent'], $_SESSION['otp_verified']);
        $msg = "Your password has been changed successfully.";

        // Force page refresh to reset button visibility
        echo "<script>
            alert('Your password has been changed successfully.');
            window.location.href = 'update-password.php';
        </script>";
        exit;
    } else {
        $error = "OTP verification required.";
    }
}

}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Car Rental Portal - Update Password</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .custom-btn {
             width: 150px; /* Adjust as needed */
        }
        /* Custom width for input boxes */
        .custom-input {
          width: 300px !important; /* Adjust width as needed */
          max-width: 100%; /* Ensures responsiveness */
       }
    </style>

    <script>
    function valid() {
        if (document.chngpwd.newpassword.value != document.chngpwd.confirmpassword.value) {
            alert("New Password and Confirm Password do not match!");
            document.chngpwd.confirmpassword.focus();
            return false;
        }
        return true;
    }

    function toggleVisibility() {
        let otpSent = <?php echo isset($_SESSION['otp_sent']) ? 'true' : 'false'; ?>;
        let otpVerified = <?php echo isset($_SESSION['otp_verified']) ? 'true' : 'false'; ?>;

        if (otpSent) {
            document.getElementById("otp_section").style.display = "block";
            document.getElementById("send_otp_btn").style.display = "none";
            document.getElementById("otp").removeAttribute("disabled");
        }
        if (otpVerified) {
            document.getElementById("password_section").style.display = "block";
            document.getElementById("otp_verify_btn").style.display = "none";
            document.getElementById("newpassword").removeAttribute("disabled");
            document.getElementById("confirmpassword").removeAttribute("disabled");
        }
    }
    window.onload = toggleVisibility;

    // Function to remove 'required' attribute when Resend OTP is clicked
    function removeRequired() {
        document.getElementById("otp").removeAttribute("required");
        document.getElementById("newpassword").removeAttribute("required");
        document.getElementById("confirmpassword").removeAttribute("required");
    }
    </script>
</head>
<body>

<?php include('includes/header.php'); ?>

<section class="page-header profile_page">
    <div class="container">
        <div class="page-header_wrap">
            <div class="page-heading">
                <h1>Update Password</h1>
            </div>
        </div>
    </div>
</section>

<section class="user_profile inner_pages">
    <div class="container">
        <div class="profile_wrap">
            <form name="chngpwd" method="post" onSubmit="return valid();">
                <div class="gray-bg field-title">
                    <h6>Update Password</h6>
                </div>
                
                <?php if ($error) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div>
                <?php } elseif ($msg) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div>
                <?php } ?>

                <!-- Send OTP Button -->
                <div class="form-group" id="send_otp_btn">
                    <input type="submit" name="sendotp" value="Send OTP" class="btn custom-btn">
                </div>

                <!-- OTP Section -->
                <div id="otp_section" style="display:none;">
                    <div class="form-group">
                        <label class="control-label">Enter OTP</label>
                        <input class="form-control white_bg custom-input" id="otp" type="text" name="otp" disabled required>
                    </div>
                    <div class="form-group" id="otp_verify_btn">
                         <input type="submit" value="Verify OTP" name="verifyotp" class="btn custom-btn">
                     </div>                 

                    <!-- Resend OTP Button -->
                    <div class="form-group">
                        <input type="submit" value="Resend OTP" name="resendotp" class="btn btn-warning custom-btn" onclick="removeRequired()">
                    </div>
                </div>

                <!-- Password Section -->
                <div id="password_section" style="display:none;">
                    <div class="form-group">
                        <label class="control-label">New Password</label>
                        <input class="form-control white_bg custom-input" id="newpassword" type="password" name="newpassword" disabled required>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Confirm Password</label>
                        <input class="form-control white_bg custom-input" id="confirmpassword" type="password" name="confirmpassword" disabled required>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Update Password" name="updatepass" class="btn custom-btn">
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>

<?php include('includes/footer.php'); ?>
</body>
</html>
