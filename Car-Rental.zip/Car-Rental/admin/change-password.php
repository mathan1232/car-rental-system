<?php
session_start();
error_reporting(0);
include('includes/config.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Directly specify the admin email
$admin_email = "shreeram56881@gmail.com"; // Change this to your actual admin email

// Step 1: Send OTP
if (isset($_POST['send_otp']) || isset($_POST['resend_otp'])) {
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = md5($otp);
    $_SESSION['otp_expiry'] = time() + 300; // OTP expires in 5 minutes
    $_SESSION['step'] = 'verify_otp';

    // Send OTP via Email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jackrosee354@gmail.com';
        $mail->Password = 'masvrjdgettibslo';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('jackrosee354@gmail.com', 'Car Rental Portal');
        $mail->addAddress($admin_email);
        $mail->Subject = "Your OTP for Password Reset";
        $mail->Body = "Your OTP is: $otp. It is valid for 5 minutes.";

        $mail->send();
        $msg = isset($_POST['resend_otp']) ? "OTP resent successfully." : "OTP sent successfully.";
    } catch (Exception $e) {
        $error = "OTP could not be sent. Mailer Error: " . $mail->ErrorInfo;
    }
}

// Step 2: Verify OTP
if (isset($_POST['verify_otp'])) {
    $otp_entered = md5($_POST['otp']);

    if (!isset($_SESSION['otp']) || $_SESSION['otp'] !== $otp_entered || time() > $_SESSION['otp_expiry']) {
        $error = "Invalid OTP or OTP expired.";
    } else {
        $_SESSION['step'] = 'set_password';
        $msg = "OTP verified successfully. Now set your new password.";
    }
}

// Step 3: Set New Password
if (isset($_POST['set_password'])) {
    $newpassword = $_POST['newpassword'];
    $confirmpassword = $_POST['confirmpassword'];

    if ($newpassword !== $confirmpassword) {
        $error = "Passwords do not match!";
    } else {
        $hashedPassword = md5($newpassword);
        $username = $_SESSION['alogin']; // Assuming session holds the username
        $sql = "UPDATE admin SET Password = :newpassword WHERE UserName = :username";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->bindParam(':newpassword', $hashedPassword, PDO::PARAM_STR);
        $stmt->execute();

        $msg = "Your password has been successfully changed.";
        unset($_SESSION['otp']); // Clear OTP session
        unset($_SESSION['step']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Car Rental Portal | Admin Change Password</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script>
        function validatePasswords() {
            if (document.chngpwd.newpassword.value !== document.chngpwd.confirmpassword.value) {
                alert("New Password and Confirm Password do not match!");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="ts-main-content">
        <?php include('includes/leftbar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <h2 class="page-title">Change Password</h2>

                <div class="panel panel-default">
                    <div class="panel-heading">Password Reset</div>
                    <div class="panel-body">
                        <?php if ($error) { ?><div class="errorWrap"><?php echo htmlentities($error); ?></div><?php } ?>
                        <?php if ($msg) { ?><div class="succWrap"><?php echo htmlentities($msg); ?></div><?php } ?>

                        <?php if (!isset($_SESSION['step']) || $_SESSION['step'] == 'send_otp') { ?>
                            <!-- Step 1: Send OTP -->
                            <form method="post">
                                <button class="btn btn-primary" name="send_otp" type="submit">Send OTP</button>
                            </form>

                        <?php } elseif ($_SESSION['step'] == 'verify_otp') { ?>
                            <!-- Step 2: Verify OTP -->
                            <form method="post">
                                <div class="form-group">
                                    <label>Enter OTP</label>
                                    <input type="text" class="form-control" name="otp" required>
                                </div>
                                <button class="btn btn-success" name="verify_otp" type="submit">Verify OTP</button>
                                <button class="btn btn-warning" name="resend_otp" type="submit">Resend OTP</button>
                            </form>

                        <?php } elseif ($_SESSION['step'] == 'set_password') { ?>
                            <!-- Step 3: Set New Password -->
                            <form method="post" name="chngpwd" onsubmit="return validatePasswords();">
                                <div class="form-group">
                                    <label>New Password</label>
                                    <input type="password" class="form-control" name="newpassword" required>
                                </div>
                                <div class="form-group">
                                    <label>Confirm Password</label>
                                    <input type="password" class="form-control" name="confirmpassword" required>
                                </div>
                                <button class="btn btn-success" name="set_password" type="submit">Set Password</button>
                            </form>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.min.js"></script>
</body>
</html>
