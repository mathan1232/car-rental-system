<?php
session_start();
error_reporting(0);
include('includes/config.php');
require('includes/fpdf/fpdf.php'); // Include FPDF Library

class PDF extends FPDF {
    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0) {
            $w = $this->w - $this->rMargin - $this->x;
        }
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb - 1] == "\n") {
            $nb--;
        }
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while ($i < $nb) {
            $c = $s[$i];
            if ($c == "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if ($c == ' ') {
                $sep = $i;
            }
            $l += $cw[$c];
            if ($l > $wmax) {
                if ($sep == -1) {
                    if ($i == $j) {
                        $i++;
                    }
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
}

if(strlen($_SESSION['alogin']) == 0) { 
    header('location:index.php');
} else {
    if(isset($_POST['generate_pdf'])) {
        $reportType = $_POST['reportType']; 
        $selectedDate = $_POST['selectedDate']; 
        $fromDate = $_POST['fromDate']; 
        $toDate = $_POST['toDate']; 

        if ($reportType == "single") {
            $sql = "SELECT tblusers.FullName, tblbrands.BrandName, tblvehicles.VehiclesTitle, 
                           tblbooking.FromDate, tblbooking.ToDate, tblbooking.message, 
                           tblbooking.Status, tblbooking.PostingDate 
                    FROM tblbooking 
                    JOIN tblvehicles ON tblvehicles.id = tblbooking.VehicleId 
                    JOIN tblusers ON tblusers.EmailId = tblbooking.userEmail 
                    JOIN tblbrands ON tblvehicles.VehiclesBrand = tblbrands.id 
                    WHERE DATE(tblbooking.PostingDate) = :selectedDate";

            $query = $dbh->prepare($sql);
            $query->bindParam(':selectedDate', $selectedDate, PDO::PARAM_STR);
            $reportTitle = "Booking Report for " . date("d M Y", strtotime($selectedDate));
        } else {
            $sql = "SELECT tblusers.FullName, tblbrands.BrandName, tblvehicles.VehiclesTitle, 
                           tblbooking.FromDate, tblbooking.ToDate, tblbooking.message, 
                           tblbooking.Status, tblbooking.PostingDate 
                    FROM tblbooking 
                    JOIN tblvehicles ON tblvehicles.id = tblbooking.VehicleId 
                    JOIN tblusers ON tblusers.EmailId = tblbooking.userEmail 
                    JOIN tblbrands ON tblvehicles.VehiclesBrand = tblbrands.id 
                    WHERE tblbooking.PostingDate BETWEEN :fromDate AND :toDate";

            $query = $dbh->prepare($sql);
            $query->bindParam(':fromDate', $fromDate, PDO::PARAM_STR);
            $query->bindParam(':toDate', $toDate, PDO::PARAM_STR);
            $reportTitle = "Booking Report from " . date("d M Y", strtotime($fromDate)) . " to " . date("d M Y", strtotime($toDate));
        }

        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_OBJ);

        if (empty($results)) {
            echo "<script>alert('No bookings in given date'); window.history.back();</script>";
            exit();
        }

        // Initialize PDF
        $pdf = new PDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 14);
                // Company Header
$pdf->SetFont('Arial', 'B', 20);
$pdf->SetTextColor(0, 102, 204);
$pdf->Cell(190, 10, 'Car Rental Services', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(0);
$pdf->Cell(190, 6, 'keela raja veethi,pudukkottai, Tamil Nadu', 0, 1, 'C');
$pdf->Cell(190, 6, 'Phone: +91 63817 61984 | Email: shreeram56881@gmail.com', 0, 1, 'C');
$pdf->Ln(10);

        // Report Title
        $pdf->SetFillColor(0, 102, 204); 
        $pdf->SetTextColor(255, 255, 255); 
        $pdf->Cell(190, 12, $reportTitle, 1, 1, 'C', true);

        // Reset text color
        $pdf->SetTextColor(0, 0, 0);

        // Table Headers
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->SetFillColor(192, 192, 192);
        $header = ['Name', 'Vehicle', 'From Date', 'To Date', 'Status', 'Posting Date'];
        $widths = [40, 50, 25, 25, 20, 30];

        foreach ($header as $index => $col) {
            $pdf->Cell($widths[$index], 10, $col, 1, 0, 'C', true);
        }
        $pdf->Ln();

        // Table Data with Proper Alignment
        $pdf->SetFont('Arial', '', 10);

        foreach ($results as $row) {
            $status = ($row->Status == 0) ? 'Pending' : (($row->Status == 1) ? 'Confirmed' : 'Cancelled');
            $formattedPostingDate = date("Y-m-d", strtotime($row->PostingDate));
            $data = [
                $row->FullName,
                $row->BrandName . ' ' . $row->VehiclesTitle,
                $row->FromDate,
                $row->ToDate,
                $status,
                $formattedPostingDate
            ];

            // Determine the maximum row height
            $maxHeight = 0;
            $cellHeights = [];
            foreach ($data as $index => $text) {
                $lines = $pdf->NbLines($widths[$index], $text);
                $cellHeight = 6 * $lines; 
                $cellHeights[$index] = $cellHeight;
                if ($cellHeight > $maxHeight) {
                    $maxHeight = $cellHeight;
                }
            }

            // Draw the cells with proper alignment
            $yStart = $pdf->GetY();
            foreach ($data as $index => $text) {
                $xStart = $pdf->GetX();
                $pdf->MultiCell($widths[$index], 6, $text, 1, 'L');
                $pdf->SetXY($xStart + $widths[$index], $yStart);
            }
            $pdf->Ln($maxHeight);
        }

        $pdf->Output('D', 'Booking_Report.pdf');
        exit();
    }
}
?>
