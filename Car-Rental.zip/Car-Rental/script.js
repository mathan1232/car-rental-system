// Get buttons and modals
const servicesBtn = document.getElementById("services-btn");
const achievementsBtn = document.getElementById("achievements-btn");
const servicesModal = document.getElementById("services-modal");
const achievementsModal = document.getElementById("achievements-modal");
const closeButtons = document.querySelectorAll(".close");

// Open modals
servicesBtn.addEventListener("click", () => {
  servicesModal.style.display = "block";
});

achievementsBtn.addEventListener("click", () => {
  achievementsModal.style.display = "block";
});

// Close modals
closeButtons.forEach((btn) => {
  btn.addEventListener("click", (event) => {
    const modalId = event.target.getAttribute("data-modal");
    document.getElementById(modalId).style.display = "none";
  });
});

// Close modals when clicking outside the content
window.addEventListener("click", (event) => {
  if (event.target.classList.contains("modal")) {
    event.target.style.display = "none";
  }
});
