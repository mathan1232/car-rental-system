<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Car Listing Navigation</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="path/to/font-awesome.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <!-- Custom CSS -->
  <style>
    /* Custom button size */
    .login_btn .btn {
      padding: 10px 20px;
      font-size: 16px;
      height: auto;
      border-radius: 5px;
    }

    .login_btn .btn:hover {
      background-color: #f44336;
      color: white;
    }

    .navbar-default .navbar-nav > li > a {
      color: white !important;
      transition: color 0.3s ease;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #FF3838 !important;
    }

    .navbar-nav .dropdown-menu {
      background-color: #333;
      border: 1px solid #ccc;
    }

    .navbar-nav .dropdown-menu li a {
      color: white;
    }

    .navbar-nav .dropdown-menu li a:hover {
      background-color: #444;
    }

    /* Fuel options styling */
    .fuel-options {
     position: absolute;
     left: 100%;
     top: 0;
     z-index: 999;
     width: 120px;
     background-color: #555;
     padding: 5px;
    display: none;
    }


    .fuel-options li a {
      color: white;
      padding: 5px 10px;
      display: block;
    }

    .fuel-options li a:hover {
      background-color: #444;
    }

    .header_info {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    /*user options nav */
    
  </style>
</head>
<body>
<header>
  <div class="default-header">
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-md-2">
          <div class="logo">
            <a href="index.php"><img src="assets/images/logo.png" alt="Logo"/></a>
          </div>
        </div>
        <div class="col-sm-9 col-md-10">
          <div class="header_info">
            <?php
            $sql = "SELECT EmailId, ContactNo FROM tblcontactusinfo";
            $query = $dbh->prepare($sql);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);
            foreach ($results as $result) {
              $email = $result->EmailId;
              $contactno = $result->ContactNo;
            }
            ?>   
            <div class="header_widgets">
              <div class="circle_icon"><i class="fa fa-envelope"></i></div>
              <p class="uppercase_text">For Support Mail us:</p>
              <a href="mailto:<?php echo htmlentities($email); ?>"><?php echo htmlentities($email); ?></a>
            </div>
            <div class="header_widgets">
              <div class="circle_icon"><i class="fa fa-phone"></i></div>
              <p class="uppercase_text">Service Helpline Call Us:</p>
              <a href="tel:<?php echo htmlentities($contactno); ?>"><?php echo htmlentities($contactno); ?></a>
            </div>
            <?php if (strlen($_SESSION['login']) == 0) { ?>
              <div class="login_btn">
                <a href="#loginform" class="btn btn-xs uppercase" data-toggle="modal" data-dismiss="modal">Login / Register</a>
              </div>
            <?php } else {
              echo "Welcome to Car Rental Portal";
            } ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Navigation -->
  <nav id="navigation_bar" class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button id="menu_slide" data-target="#navigation" aria-expanded="false" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
      <div class="header_wrap">
        <div class="user_login">
          <ul>
            <li class="dropdown">
              <a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user-circle"></i>
                <?php
                $email = $_SESSION['login'];
                $sql = "SELECT FullName FROM tblusers WHERE EmailId=:email";
                $query = $dbh->prepare($sql);
                $query->bindParam(':email', $email, PDO::PARAM_STR);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);
                if ($query->rowCount() > 0) {
                  foreach ($results as $result) {
                    echo htmlentities($result->FullName);
                  }
                }
                ?>
              </a>
            </li>
          </ul>
        </div>
        
        <div class="header_search">
          <div id="search_toggle"><i class="fa fa-search"></i></div>
          <form action="search.php" method="post" id="header-search-form">
            <input type="text" placeholder="Search..." name="searchdata" class="form-control" required>
            <button type="submit"><i class="fa fa-search"></i></button>
          </form>
        </div>
      </div>
      <div class="collapse navbar-collapse" id="navigation">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="page.php?type=aboutus">About Us</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Car Listing
            </a>
            <ul class="dropdown-menu">

            <li class="car-item" onclick="toggleFuelOptions(event)">
                <a href="car-listing.php">ALL CARS</a>
              </li>

              <li class="car-item" onclick="toggleFuelOptions(event)">
                <a href="#">Maruti</a>
                <ul class="fuel-options">
                  <li><a href="demo.php?brand=Maruti&fueltype=Petrol">Petrol</a></li>
                  <li><a href="demo.php?brand=Maruti&fueltype=Diesel">Diesel</a></li>
                </ul>
              </li>
              <li class="car-item" onclick="toggleFuelOptions(event)">
                <a href="#">BMW</a>
                <ul class="fuel-options">
                  <li><a href="demo.php?brand=BMW&fueltype=Petrol">Petrol</a></li>
                  <li><a href="demo.php?brand=BMW&fueltype=Diesel">Diesel</a></li>
                </ul>
              </li>
              <li class="car-item" onclick="toggleFuelOptions(event)">
                <a href="#">Audi</a>
                <ul class="fuel-options">
                  <li><a href="demo.php?brand=Audi&fueltype=Petrol">Petrol</a></li>
                  <li><a href="demo.php?brand=Audi&fueltype=Diesel">Diesel</a></li>
                </ul>
              </li>
              <li class="car-item" onclick="toggleFuelOptions(event)">
                <a href="#">Nissan</a>
                <ul class="fuel-options">
                  <li><a href="demo.php?brand=Nissan&fueltype=Petrol">Petrol</a></li>
                  <li><a href="demo.php?brand=Nissan&fueltype=Diesel">Diesel</a></li>
                  <li><a href="demo.php?brand=Nissan&fueltype=CNG">CNG</a></li>
                </ul>
              </li>
              <li class="car-item" onclick="toggleFuelOptions(event)">
                <a href="#">Toyota</a>
                <ul class="fuel-options">
                  <li><a href="demo.php?brand=Toyota&fueltype=Petrol">Petrol</a></li>
                  <li><a href="demo.php?brand=Toyota&fueltype=Diesel">Diesel</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href="page.php?type=faqs">FAQs</a></li>
          <li><a href="contact-us.php">Contact Us</a></li>
          <?php if (isset($_SESSION['login']) && strlen($_SESSION['login']) > 0) { ?>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                User
              </a>
              <ul class="dropdown-menu">
                <li><a href="logout.php">sign out</a></li>
                <li><a href="profile.php">Profile Settings</a></li>
                <li><a href="captcha.php">Update Password</a></li>
                <li><a href="my-booking.php">My Booking</a></li>
                <li><a href="post-testimonial.php">Post a Testimonial</a></li>
                <li><a href="my-testimonials.php">My Testimonial</a></li>
              </ul>
            </li>
          <?php } ?>
        </ul>
      </div>
    </div>
  </nav>
</header>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>
  document.addEventListener('click', function(e) {
    document.querySelectorAll('.fuel-options').forEach(option => {
      if (!option.contains(e.target)) option.style.display = 'none';
    });
  });

  // Function to toggle the fuel options visibility on click
  function toggleFuelOptions(event) {
  event.stopPropagation();
  
  // Close all other fuel options
  document.querySelectorAll('.fuel-options').forEach(function(option) {
    if (option !== event.currentTarget.querySelector('.fuel-options')) {
      option.style.display = 'none';
    }
  });

  var fuelOptions = event.currentTarget.querySelector('.fuel-options');
  fuelOptions.style.display = fuelOptions.style.display === 'block' ? 'none' : 'block';
}

</script>
</body>
</html>
