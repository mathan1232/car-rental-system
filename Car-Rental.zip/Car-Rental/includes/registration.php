<?php 
// error_reporting(0);
if(isset($_POST['signup'])) {
    $fname = $_POST['fullname'];
    $email = $_POST['emailid']; 
    $mobile = $_POST['mobileno'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];

    // Handling file uploads
    $licenseFile = $_FILES['license']['name'];
    $licenseTmp = $_FILES['license']['tmp_name'];
    $licenseFolder = "uploads/licenses/" . basename($licenseFile);

    $profilePhoto = $_FILES['profilephoto']['name'];
    $profileTmp = $_FILES['profilephoto']['tmp_name'];
    $profileFolder = "uploads/photos/" . basename($profilePhoto);

    // Create directories if they don't exist
    if (!is_dir("uploads/licenses/")) {
        mkdir("uploads/licenses/", 0777, true);
    }
    if (!is_dir("uploads/photos/")) {
        mkdir("uploads/photos/", 0777, true);
    }

    // Check if passwords match
    if ($password == $confirmpassword) {
        $hashedPassword = md5($password); // Hash the password

        // Move uploaded files
        if (move_uploaded_file($licenseTmp, $licenseFolder) && move_uploaded_file($profileTmp, $profileFolder)) {
            $sql = "INSERT INTO tblusers(FullName, EmailId, ContactNo, Password, LicensePath, ProfilePhotoPath) VALUES(:fname, :email, :mobile, :password, :license, :photo)";
            $query = $dbh->prepare($sql);
            $query->bindParam(':fname', $fname, PDO::PARAM_STR);
            $query->bindParam(':email', $email, PDO::PARAM_STR);
            $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
            $query->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
            $query->bindParam(':license', $licenseFolder, PDO::PARAM_STR);
            $query->bindParam(':photo', $profileFolder, PDO::PARAM_STR);
            $query->execute();

            $lastInsertId = $dbh->lastInsertId();
            if ($lastInsertId) {
                echo "<script>alert('Registration successful. Now you can login');</script>";
            } else {
                echo "<script>alert('Something went wrong. Please try again');</script>";
            }
        } else {
            echo "<script>alert('Failed to upload files.');</script>";
        }
    } else {
        echo "<script>alert('Passwords do not match. Please try again.');</script>";
    }
}
?>

<style>
/* Hide password reveal icon in Edge, Chrome, and Safari */
input::-ms-reveal,
input::-webkit-contacts-auto-fill-button,
input::-webkit-credentials-auto-fill-button {
    display: none !important;
}

/* Make modal body scrollable */
.modal-body {
    max-height: 400px;
    overflow-y: auto;
}
</style>

<script>
function checkAvailability() {
    $("#loaderIcon").show();
    jQuery.ajax({
        url: "check_availability.php",
        data: 'emailid=' + $("#emailid").val(),
        type: "POST",
        success: function(data) {
            $("#user-availability-status").html(data);
            $("#loaderIcon").hide();
        },
        error: function() {}
    });
}

// Client-side password match validation
document.querySelector('form[name="signup"]').addEventListener('submit', function(event) {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmpassword").value;

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        event.preventDefault();
    }
});
</script>

<!-- Modal for Sign Up -->
<div class="modal fade" id="signupform">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Sign Up</h3>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="signup_wrap">
            <div class="col-md-12 col-sm-6">
              <form method="post" name="signup" enctype="multipart/form-data">
                <div class="form-group">
                  <input type="text" class="form-control" name="fullname" placeholder="Full Name" required="required">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="mobileno" placeholder="Mobile Number" maxlength="10" required="required">
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" name="emailid" id="emailid" onBlur="checkAvailability()" placeholder="Email Address" required="required">
                  <span id="user-availability-status" style="font-size:12px;"></span> 
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" id="password" name="password" placeholder="Password" required="required">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password" required="required">
                </div>
                <div class="form-group">
                  <label for="license">Upload Driving License:</label>
                  <input type="file" class="form-control" name="license" id="license" accept=".pdf,.jpg,.jpeg,.png" required="required">
                </div>
                <div class="form-group">
                  <label for="profilephoto">Upload Profile Photo:</label>
                  <input type="file" class="form-control" name="profilephoto" id="profilephoto" accept=".jpg,.jpeg,.png" required="required">
                </div>
                <div class="form-group checkbox">
                  <input type="checkbox" id="terms_agree" required="required" checked="">
                  <label for="terms_agree">I Agree with <a href="#">Terms and Conditions</a></label>
                </div>
                <div class="form-group">
                  <input type="submit" value="Sign Up" name="signup" id="submit" class="btn btn-block">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer text-center">
        <p>Already got an account? <a href="#loginform" data-toggle="modal" data-dismiss="modal">Login Here</a></p>
      </div>
    </div>
  </div>
</div>
