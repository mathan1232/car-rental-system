<?php
require('fpdf/fpdf.php'); // Include FPDF Library
include('includes/config.php');
session_start();

if (!isset($_GET['booking_no'])) {
    die("Invalid Request");
}

$booking_no = $_GET['booking_no'];

// Fetch Booking Details
$sql = "SELECT tblvehicles.VehiclesTitle, tblvehicles.PricePerDay, tblbrands.BrandName, tblbooking.FromDate, tblbooking.ToDate, 
        DATEDIFF(tblbooking.ToDate, tblbooking.FromDate) as totaldays, tblusers.FullName, tblusers.EmailId, tblusers.ContactNo, tblusers.ProfilePhotoPath 
        FROM tblbooking 
        JOIN tblvehicles ON tblbooking.VehicleId=tblvehicles.id 
        JOIN tblbrands ON tblbrands.id=tblvehicles.VehiclesBrand 
        JOIN tblusers ON tblbooking.userEmail=tblusers.EmailId 
        WHERE tblbooking.BookingNumber=:booking_no AND tblbooking.Status=1";
      
$query = $dbh->prepare($sql);
$query->bindParam(':booking_no', $booking_no, PDO::PARAM_STR);
$query->execute();
$result = $query->fetch(PDO::FETCH_OBJ);

if (!$result) {
    die("Booking not found or not confirmed.");
}

// Calculate Total Cost
$total_cost = $result->totaldays * $result->PricePerDay;

// Generate PDF Invoice
$pdf = new FPDF();
$pdf->AddPage();

// Company Header
$pdf->SetFont('Arial', 'B', 20);
$pdf->SetTextColor(0, 102, 204);
$pdf->Cell(190, 10, 'Car Rental Services', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(0);
$pdf->Cell(190, 6, 'keela raja veethi,pudukkottai, Tamil Nadu', 0, 1, 'C');
$pdf->Cell(190, 6, 'Phone: +91 63817 61984 | Email: shreeram56881@gmail.com', 0, 1, 'C');
$pdf->Ln(10);

// Invoice Title
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetFillColor(200, 220, 255);
$pdf->Cell(190, 10, 'Car Rental Invoice', 0, 1, 'C', true);
$pdf->Ln(5);

// Add Profile Picture
$profilePicPath = $_SERVER['DOCUMENT_ROOT'] . '/Car-Rental/' . $result->ProfilePhotoPath;
if (file_exists($profilePicPath) && !empty($result->ProfilePhotoPath)) {
    $pdf->Image($profilePicPath, 150, 40, 40, 40);
} else {
    $pdf->SetFont('Arial', 'I', 10);
    $pdf->Text(150, 60, 'No Profile Picture');
}

// Customer Details
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(95, 10, 'Customer Details', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 8, 'Name: ' . $result->FullName, 0, 1);
$pdf->Cell(95, 8, 'Email: ' . $result->EmailId, 0, 1);
$pdf->Cell(95, 8, 'Mobile: ' . $result->ContactNo, 0, 1);
$pdf->Cell(95, 8, 'Booking No: ' . $booking_no, 0, 1);
$pdf->Ln(5);

// Car & Booking Details
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(95, 10, 'Booking Details', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 8, 'Car: ' . $result->BrandName . ' - ' . $result->VehiclesTitle, 0, 1);
$pdf->Cell(95, 8, 'From: ' . $result->FromDate, 0, 1);
$pdf->Cell(95, 8, 'To: ' . $result->ToDate, 0, 1);
$pdf->Cell(95, 8, 'Total Days: ' . $result->totaldays, 0, 1);
$pdf->Cell(95, 8, 'Price Per Day: Rs. ' . $result->PricePerDay, 0, 1);
$pdf->Ln(5);

// Total Cost Highlighted
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetFillColor(255, 230, 230);
$pdf->Cell(95, 12, 'Total Amount: Rs. ' . $total_cost, 1, 1, 'C', true);

// Footer
$pdf->Ln(10);
$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(190, 6, 'Thank you for choosing Car Rental Services!', 0, 1, 'C');
$pdf->Cell(190, 6, 'For inquiries, contact us at shreeram56881@gmail.com', 0, 1, 'C');

$pdf->Output('D', "Invoice_$booking_no.pdf"); // Force download
?>