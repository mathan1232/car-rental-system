<?php 
session_start();
include('includes/config.php');
error_reporting(0);

?>

<!DOCTYPE HTML>
<html lang="en">
<head>

<title>Car Rental Portal</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<link href="assets/css/slick.css" rel="stylesheet">
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--<link href="assets/css/font-awesome.min.css" rel="stylesheet">-->
<link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="styles.css"> <!--For modal-->



<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon-icon/apple-touch-icon-114-precomposed.html">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet"> 
<!--custom css-->

<style>
   .customer-rating i {
  color: #FFD700; /* Gold color for filled stars */
  margin-right: 5px; /* Space between stars */
}

.testimonial-date {
  font-size: 0.9em;
  color: #777;
  margin-top: 10px;
}

.customer-rating .fa-star-o {
  color: #ccc; /* Gray color for empty stars */
}

 /* General modal styles */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    animation: fadeIn 0.5s ease-in-out;
}

.modal-content {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    margin: 10% auto;
    padding: 30px;
    border-radius: 12px;
    width: 55%;
    max-width: 650px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    font-family: 'Poppins', sans-serif;
    position: relative;
    text-align: center;
    animation: slideUp 0.6s ease-out;
}

.modal-content h2 {
    font-size: 28px;
    font-weight: 600;
    color: #222;
    margin-bottom: 15px;
}

.modal-content ul {
    list-style: none;
    padding: 0;
}

.modal-content ul li {
    font-size: 18px;
    color: #444;
    margin: 10px 0;
    padding: 8px;
    border-bottom: 1px solid #ddd;
    transition: 0.3s;
}

.modal-content ul li:hover {
    color: #ff5e00;
    transform: scale(1.05);
}

.close {
    color: #ff5e00;
    float: right;
    font-size: 28px;
    cursor: pointer;
    transition: 0.3s;
}

.close:hover {
    color: #d9534f;
    transform: rotate(90deg);
}

/* Floating Buttons */
#floating-buttons {
    position: fixed;
    left: 20px;  /* Adjusted to left side */
    top: 50%;
    transform: translateY(-50%); /* Centering vertically */
    display: flex;
    flex-direction: column;
    gap: 15px;
}

/* Floating Button Styling */
#floating-buttons button {
    background: linear-gradient(135deg, #ff5e00, #ff9000);
    color: white;
    border: none;
    padding: 12px 18px;
    font-size: 18px;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 10px rgba(255, 94, 0, 0.4);
}

#floating-buttons button:hover {
    box-shadow: 0 6px 20px rgba(255, 94, 0, 0.6);
    transform: translateY(-3px);
}

/* Responsive Fix for Smaller Screens */
@media (max-width: 600px) {
    #floating-buttons {
        left: 10px; /* Adjust position for smaller screens */
    }

    #floating-buttons button {
        padding: 10px 15px;
        font-size: 16px;
    }
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideUp {
    from { transform: translateY(40px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

/* Responsive Design */
@media (max-width: 600px) {
    .modal-content {
        width: 90%;
        padding: 20px;
    }

    .modal-content h2 {
        font-size: 22px;
    }

    .modal-content ul li {
        font-size: 16px;
    }
}

/* Stylish Modal Headings */
.modal h2 {
    font-size: 28px;
    font-weight: bold;
    text-align: center;
    text-transform: uppercase;
    background: linear-gradient(90deg,rgb(255, 0, 0),rgb(255, 0, 0));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: 2px;
    margin-bottom: 15px;
    position: relative;
    display: inline-block;
}

/* Underline Animation */
.modal h2::after {
    content: "";
    display: block;
    width: 60%;
    height: 3px;
    background: linear-gradient(90deg,rgb(255, 0, 0),rgb(255, 0, 0));
    margin: 5px auto 0;
    animation: underlineExpand 1s ease-in-out infinite alternate;
}

/* Underline Animation Keyframes */
@keyframes underlineExpand {
    0% {
        width: 40%;
    }
    100% {
        width: 80%;
    }
}

/* Glowing Effect on Hover */
.modal h2:hover {
    text-shadow: 0 0 10px rgba(255, 0, 0, 0.8);
    transition: text-shadow 0.3s ease-in-out;
}



</style>

</head>
<body>
        
<!--Header-->
<?php include('includes/header.php');?>
<!-- /Header --> 

<!-- Banners -->
<section id="banner" class="banner-section">
  <div class="container">
    <div class="div_zindex">
      <div class="row">
        <div class="col-md-5 col-md-push-7">
          <div class="banner_content">
            <h1>&nbsp;</h1>
            <p>&nbsp; </p>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /Banners --> 


<!-- Resent Cat-->
<section class="section-padding gray-bg">
  <div class="container">
    <div class="section-header text-center">
      <h2>Find the Best <span>CarForYou</span></h2>
      <p><b>Welcome to our Car Rental Service ! </b>
      Experience seamless car rentals with our user-friendly platform. Choose from a wide range of vehicles, enjoy competitive pricing, and hit the road with confidence—anytime, anywhere!</p>
    </div>
    <div class="row"> 
      
      <!-- Nav tabs -->
      <div class="recent-tab">
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#resentnewcar" role="tab" data-toggle="tab">New Car</a></li>
        </ul>
      </div>
      <!-- Recently Listed New Cars -->
      <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="resentnewcar">

<?php $sql = "SELECT tblvehicles.VehiclesTitle,tblbrands.BrandName,tblvehicles.PricePerDay,tblvehicles.FuelType,tblvehicles.ModelYear,tblvehicles.id,tblvehicles.SeatingCapacity,tblvehicles.VehiclesOverview,tblvehicles.Vimage1 from tblvehicles join tblbrands on tblbrands.id=tblvehicles.VehiclesBrand limit 9";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  
?>  

<div class="col-list-3">
<div class="recent-car-list">
<div class="car-info-box"> <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"><img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1);?>" class="img-responsive" alt="image"></a>
<ul>
<li><i class="fa fa-car" aria-hidden="true"></i><?php echo htmlentities($result->FuelType);?></li>
<li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo htmlentities($result->ModelYear);?> Model</li>
<li><i class="fa fa-user" aria-hidden="true"></i><?php echo htmlentities($result->SeatingCapacity);?> seats</li>
</ul>
</div>
<div class="car-title-m">
<h6><a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>"> <?php echo htmlentities($result->VehiclesTitle);?></a></h6>
<span class="price">₹<?php echo htmlentities($result->PricePerDay);?> /Day</span> 
</div>
<div class="inventory_info_m">
<p><?php echo substr($result->VehiclesOverview,0,70);?></p>
</div>
</div>
</div>
<?php }}?>
       
      </div>
    </div>
  </div>
</section>
<!-- /Resent Cat --> 

<!-- Fun Facts-->
<section class="fun-facts-section">
  <div class="container div_zindex">
    <div class="row">
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-calendar" aria-hidden="true"></i>40+</h2>
            <p>Years In Business</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-car" aria-hidden="true"></i>1200+</h2>
            <p>New Cars For Sale</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-car" aria-hidden="true"></i>1000+</h2>
            <p>Used Cars For Sale</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6 col-sm-3">
        <div class="fun-facts-m">
          <div class="cell">
            <h2><i class="fa fa-user-circle-o" aria-hidden="true"></i>600+</h2>
            <p>Satisfied Customers</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Fun Facts--> 


<!--Testimonial -->
<section class="section-padding testimonial-section parallex-bg">
  <div class="container div_zindex">
    <div class="section-header white-text text-center">
      <h2>Our Satisfied <span>Customers</span></h2>
    </div>
    <div class="row">
      <div id="testimonial-slider">
<?php 
$tid = 1; // For active testimonials
$sql = "SELECT tbltestimonial.Testimonial, tblusers.FullName, tbltestimonial.PostingDate, tbltestimonial.Rating
        FROM tbltestimonial
        JOIN tblusers ON tbltestimonial.UserEmail = tblusers.EmailId
        WHERE tbltestimonial.status = :tid
        ORDER BY tbltestimonial.PostingDate DESC
        LIMIT 4";
$query = $dbh->prepare($sql);
$query->bindParam(':tid', $tid, PDO::PARAM_STR);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0) {
  foreach($results as $result) {  
?>
        <div class="testimonial-m">
          <div class="testimonial-content">
            <div class="testimonial-heading">
              <h5><?php echo htmlentities($result->FullName);?></h5>
              <div class="customer-rating">
                <?php 
                  $rating = (int)$result->Rating; // ensure rating is an integer 
                  echo $result->Rating." "; // To see the value of the rating
                 // echo "hii da mathan";
                  // Display stars based on the rating
                  for($i = 1; $i <= 5; $i++) {
                    if($i <= $rating) {
                      echo '<i class="fa fa-star" aria-hidden="true"></i>';//Filled star
                    } else {
                      echo '<i class="fa fa-star-o" aria-hidden="true"></i>';//empty star
                    }
                  }
                ?>
              </div>
              <p><?php echo htmlentities($result->Testimonial);?></p>
              <span class="testimonial-date"><?php echo date('F j, Y', strtotime($result->PostingDate));?></span>
            </div>
          </div>
        </div>
<?php }}?> 

      </div>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>
<!-- /Testimonial--> 

<!-- Floating Buttons and Modals -->
<div id="floating-buttons">
  <button id="services-btn" class="btn btn-primary" title="Services"><i class="fa fa-cogs"></i></button>
  <button id="achievements-btn" class="btn btn-success" title="Achievements"><i class="fa fa-trophy"></i></button>
</div>

<div id="services-modal" class="modal">
    <div class="modal-content">
        <span class="close" data-modal="services-modal">&times;</span>
        <h2>Our Services</h2>
        <ul>
            <li>Our clients are our first priority.</li>
            <li>We have partnerships all over Tamil Nadu, ensuring our clients a safe journey.</li>
            <li>
                Our premium clients can access platinum membership services, available at the nearest service center 
                anytime, anywhere.
            </li>
        </ul>
    </div>
</div>

<div id="achievements-modal" class="modal">
    <div class="modal-content">
        <span class="close" data-modal="achievements-modal">&times;</span>
        <h2>Achievements</h2>
        <ul>
            <li>We proudly hold the 3rd best car rental service rank in Tamil Nadu.</li>
            <li>Continuous improvements make our services the best in Tamil Nadu.</li>
            <li>
                The International Car Service Federation has recognized our service as one of India's finest for 
                customer friendliness and quality.
            </li>
            <li>Our clients are our first priority.</li>
            <li>
                Former car racer Steve Peterson remarked, "This car service is the best I've seen in India, meeting 
                international standards."
            </li>
        </ul>
    </div>
</div>

<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>
<!--/Back to top--> 

<!--Login-Form -->
<?php include('includes/login.php');?>
<!--/Login-Form --> 

<!--Register-Form -->
<?php include('includes/registration.php');?>

<!--/Register-Form --> 

<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>
<!--/Forgot-password-Form --> 


<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<script src="script.js"></script> <!--Custom script for modal -->


<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>

<!-- Mirrored from themes.webmasterdriver.net/carforyou/demo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 16 Jun 2017 07:22:11 GMT -->
</html>